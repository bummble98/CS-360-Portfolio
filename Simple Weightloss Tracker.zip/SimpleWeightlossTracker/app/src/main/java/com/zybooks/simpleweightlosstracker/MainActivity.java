package com.zybooks.simpleweightlosstracker;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputFilter;
import android.text.InputType;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.navigation.NavController;
import androidx.navigation.NavDestination;
import androidx.navigation.Navigation;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.zybooks.simpleweightlosstracker.databinding.ActivityMainBinding;
import com.zybooks.simpleweightlosstracker.model.Profile;
import com.zybooks.simpleweightlosstracker.model.Weight;
import com.zybooks.simpleweightlosstracker.viewmodel.MainActivityViewModel;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class MainActivity extends AppCompatActivity {
    private String username;
    private String password;
    private final MutableLiveData<List<Weight>> weightListLiveData = new MutableLiveData<>();
    private final MutableLiveData<Integer> goalWeightLiveData = new MutableLiveData<>();
    private AppBarConfiguration appBarConfiguration;
    private Menu mainActivityMenu;
    private MainActivityViewModel mainActivityViewModel;
    private final AtomicBoolean textMessageOptIn = new AtomicBoolean(false);
    private Profile userProfile;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d("MainActivity", "Main activity opened");
        com.zybooks.simpleweightlosstracker.databinding.ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        Log.d("MainActivity", "Actionbar set");

        // set navhost fragment
        Fragment navHostFragment = getSupportFragmentManager().findFragmentById(R.id.nav_host_fragment_content_main);
        Log.d("MainActivity", "NavHostFragment set");

        if (navHostFragment instanceof NavHostFragment) {
            NavController navController = ((NavHostFragment) navHostFragment).getNavController();
            Log.d("MainActivity", "Nav controller found and set");
            appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
            NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
            Log.d("MainActivity", "AppBar set");
        } else {
            Log.e("MainActivity", "NavHostFragment not found");
        }
        // connect to viewmodel
        mainActivityViewModel = new MainActivityViewModel(this.getApplication());
        // Set up profile data
        String passedUsername = getIntent().getStringExtra("profile");
        LiveData<Profile> profileLiveData = mainActivityViewModel.getProfile(passedUsername);
        profileLiveData.observe(this, profile -> {
            if (profile != null) {
                Log.d("MainActivity", "Profile live data set");
                userProfile = profile;
                username = profile.getUsername();
                password = profile.getPassword();
                goalWeightLiveData.setValue(profile.getGoalWeight());
            }
        });


    }
    public LiveData<Integer> getWeightGoalLiveData(){
        return goalWeightLiveData;
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        mainActivityMenu = menu;
        Log.d("MainActivity", "On-create options finished");
        return true;

    }
    public void setMenuDeleteWeightActionMode(boolean actionMode) {
        //todo: fix menu hide function
        // set the menu to visible or invisible for action mode
        // or modify it so only the delete button is visible
        if (mainActivityMenu != null) {
            mainActivityMenu.setGroupVisible(R.id.main_activity_menu,!actionMode);
        }
    }
    public void setMenuDeleteWeightActionModeSecondOption(boolean actionMode) {
        // set the menu for the action mode to delete items
        if (actionMode){
            mainActivityMenu.findItem(R.id.delete_weight_action).setVisible(true);
            mainActivityMenu.findItem(R.id.delete_weights_action).setVisible(false);
            mainActivityMenu.findItem(R.id.text_notifications_action).setVisible(false);
            mainActivityMenu.findItem(R.id.delete_all_data_action).setVisible(false);
        }
        else{
            mainActivityMenu.findItem(R.id.delete_weight_action).setVisible(false);
            mainActivityMenu.findItem(R.id.delete_weights_action).setVisible(true);
            mainActivityMenu.findItem(R.id.text_notifications_action).setVisible(true);
            mainActivityMenu.findItem(R.id.delete_all_data_action).setVisible(true);
        }
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //Open delete weights screen
        if (id == R.id.delete_weights_action) {
            NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
            NavDestination currentFragment = navController.getCurrentDestination();
            if (currentFragment != null) {
                int currentFragmentId = currentFragment.getId();
                if (currentFragmentId == R.id.MainFragment) {
                    navController.navigate(R.id.action_MainFragment_to_WeightDeleteScreen);

                } else if (currentFragmentId == R.id.WeightEntryFragment) {
                    navController.navigate(R.id.action_WeightEntryFragment_to_WeightDeleteScreen);

                }


            }
            Log.d("MainActivity", "Opening Delete Weights fragment");
            return true;
        }
        if (id == R.id.text_notifications_action) {
            // todo: implement text notification opt in
            Log.d("MainActivity", "Prompting for text notifications");
            AlertDialog alertDialog = new AlertDialog.Builder(this)
                    .setTitle("Text Notification")
                    .setMessage("Do you want to opt in for text notifications?")
                    .setPositiveButton("Yes", (dialogInterface, i) -> textMessageOptIn.set(true))
                    .setNegativeButton("No", (dialogInterface, i) -> textMessageOptIn.set(false))
                    .show();
            alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(MainActivity.this, R.color.md_theme_dark_primary));
            alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(MainActivity.this, R.color.md_theme_dark_primary));
            return true;
        }
        if (id == R.id.delete_all_data_action) {
            Log.d("MainActivity", "Opening Delete all data prompt");
            AlertDialog alertDialog = new AlertDialog.Builder(this)
                    .setTitle("Delete data")
                    .setMessage("Do you want to delete your account and all weight data?")
                    .setPositiveButton("Yes", (dialogInterface, i) -> mainActivityViewModel.deleteProfile(userProfile))
                    .setNegativeButton("No", null)
                    .show();
            alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(MainActivity.this, R.color.md_theme_dark_primary));
            alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(MainActivity.this, R.color.md_theme_dark_primary));
            return true;
        }
        if (id == R.id.set_goal_action) {
            promptForGoalWeight();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    private void promptForGoalWeight(){
        final EditText goalTextEdit = new EditText(this);
        goalTextEdit.setInputType(InputType.TYPE_CLASS_NUMBER);
        goalTextEdit.setFilters(new InputFilter[] {new InputFilter.LengthFilter(4)});
        // Prompt for goal entry
        Log.d("MainActivity", "Prompting for weight goal");
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setTitle("Weight Goal")
                .setMessage("What do you want your goal weight to be?")
                .setView(goalTextEdit)
                .setPositiveButton("Set", (dialogInterface, i) -> {
                    // Retrieve input text and convert it to an integer
                    String inputText = goalTextEdit.getText().toString().trim();
                    if (!inputText.isEmpty()) {
                        mainActivityViewModel.updateGoalWeight(Integer.parseInt(inputText));
                        mainActivityViewModel.getProfile(username);
                        int goal = mainActivityViewModel.getGoalWeight(username);
                        goalWeightLiveData.postValue(goal);
                    }
                    else {
                        Toast.makeText(this, "Cannot set an empty weight goal!", Toast.LENGTH_SHORT).show();
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
        alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(MainActivity.this, R.color.md_theme_dark_primary));
        alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(MainActivity.this, R.color.md_theme_dark_primary));
    }
    private void deleteAllData(){
        mainActivityViewModel.deleteProfile(userProfile);
    }
    public String getUsername(){
        return username;
    }

    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }


    private void showDeleteConfirmationDialog() {
        AlertDialog alertDialog = new AlertDialog.Builder(this)
                .setTitle("Delete Profile")
                .setMessage("Are you sure you want to delete your data?")
                .setPositiveButton("Yes", (dialogInterface, i) -> finishAffinity())
                .setNegativeButton("No", null)
                .show();
        alertDialog.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(ContextCompat.getColor(MainActivity.this, R.color.md_theme_dark_primary));
        alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(ContextCompat.getColor(MainActivity.this, R.color.md_theme_dark_primary));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

    }
}