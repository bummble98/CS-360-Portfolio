package com.zybooks.simpleweightlosstracker;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.navigation.fragment.NavHostFragment;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.zybooks.simpleweightlosstracker.databinding.FragmentMainBinding;
import com.zybooks.simpleweightlosstracker.model.Weight;
import com.zybooks.simpleweightlosstracker.viewmodel.MainFragmentViewModel;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainFragment extends Fragment {

    private FragmentMainBinding binding;
    private Thread chartSetupBackgroundThread;
    private LiveData<List<Weight>> weightsLiveData = new MutableLiveData<>();
    private String username;
    private MainFragmentViewModel mainFragmentViewModel;
    private TextView currentGoal;
    private TextView lbsTillGoal;
    private MainActivity mainActivity;
    @Override
    public View onCreateView(
            @NonNull LayoutInflater inflater, ViewGroup container,
            Bundle savedInstanceState
    ) {

        binding = FragmentMainBinding.inflate(inflater, container, false);
        return binding.getRoot();

    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        binding.openWeightEntryFragmentButton.setOnClickListener(v ->
                NavHostFragment.findNavController(MainFragment.this)
                        .navigate(R.id.action_MainFragment_to_WeightEntryFragment)
        );
        //Set up main activity reference and get username
        mainActivity = (MainActivity) requireActivity();
        username = mainActivity.getUsername();
        //Set up view model
        mainFragmentViewModel = new MainFragmentViewModel(requireActivity().getApplication());
        //Find current weight goal text view
        currentGoal = binding.currentGoal;
        lbsTillGoal = binding.lbsTillGoal;
        textViewObserverSetup();
        //Call chart setup task
        chartSetupTask(username);
        binding.lineChart.invalidate();
    }
    private void textViewObserverSetup(){
        LiveData<Integer> weightGoal =mainActivity.getWeightGoalLiveData();
        weightGoal.observe(getViewLifecycleOwner(), goal -> {
            if (goal != null) {
                currentGoal.setText(String.valueOf(goal));
                //todo set up textview setters
                int latestWeight = mainFragmentViewModel.getLatestWeight(username);
                int oldestWeight = mainFragmentViewModel.getOldestWeight(username);
                int lbsTillGoalInt = latestWeight-goal;
                String lbsTillGoalText;
                if (lbsTillGoalInt < 0) {
                    lbsTillGoalText = "Congrats!";
                }
                else {
                    lbsTillGoalText = String.valueOf(lbsTillGoalInt);
                }

                lbsTillGoal.setText(lbsTillGoalText);
                weightGoal.removeObservers(this);
            }
        });
    }
    public long dateToMillis(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        try {
            Date date = sdf.parse(dateStr);
            return date.getTime();
        } catch (ParseException e) {
            e.printStackTrace();
            return 0;
        }
    }

    private void chartSetupTask(String username) {
        LineChart lineChart = binding.lineChart;
        ArrayList<Entry> entries = new ArrayList<>();
        lineChart.getXAxis().setValueFormatter(new DateAxisValueFormatter());
        weightsLiveData = MainFragmentViewModel.getWeights(username);
        weightsLiveData.observe(getViewLifecycleOwner(),weightsData->{
            for (Weight weight:weightsData) {
                Date xValue1date = weight.getParsedDate();
                long xValue1 = dateToMillis(String.format(Locale.getDefault(), "%04d-%02d-%02d",
                        xValue1date.getYear() + 1900, xValue1date.getMonth() + 1, xValue1date.getDate()));
                float yValue1 = weight.getWeight();
                entries.add(new Entry(xValue1, yValue1)); // Add your data points here
            }
            // Add more data points as needed
            LineDataSet dataSet = new LineDataSet(entries, "Label"); // "Label" is the name of the dataset
            dataSet.setColor(Color.BLUE); // Set line color
            dataSet.setValueTextColor(Color.RED); // Set text color
            LineData lineData = new LineData(dataSet);
            lineChart.setData(lineData);
            lineChart.getXAxis().setTextColor(Color.WHITE);
            lineChart.getAxisLeft().setTextColor(Color.WHITE);
            lineChart.getDescription().setText("WeightLoss Chart");
            //lineChart.getXAxis().setValueFormatter(new XAxisValueFormatter());
            lineChart.invalidate();
        });
    }
    public class DateAxisValueFormatter extends ValueFormatter {
        private final SimpleDateFormat sdf = new SimpleDateFormat("MM/dd");

        @Override
        public String getFormattedValue(float value) {
            long millis = (long) value;
            return sdf.format(new Date(millis));
        }
    }
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
        if (chartSetupBackgroundThread != null) {
            chartSetupBackgroundThread.interrupt();
        }
    }

}