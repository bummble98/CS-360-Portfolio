package com.zybooks.simpleweightlosstracker;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.zybooks.simpleweightlosstracker.databinding.FragmentWeightDeleteScreenBinding;
import com.zybooks.simpleweightlosstracker.model.Weight;
import com.zybooks.simpleweightlosstracker.viewmodel.WeightListViewModel;
import java.util.List;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.graphics.Color;
import androidx.lifecycle.ViewModelProvider;

import java.util.Comparator;

public class WeightDeleteFragment extends Fragment {

    public enum WeightSortOrder {
        ALPHABETIC, NEW_FIRST, OLD_FIRST
    }
    private FragmentWeightDeleteScreenBinding binding;
    private WeightAdapter mWeightAdapter;
    private RecyclerView mRecyclerView;
    private int[] mWeightColors;
    private WeightListViewModel mWeightListViewModel;
    private Boolean mLoadWeightList = true;
    private Weight mSelectedWeight;
    private int mSelectedWeightPosition = RecyclerView.NO_POSITION;
    private ActionMode mActionMode = null;
    private String username;
    private MainActivity mainActivity;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                                Bundle savedInstanceState) {
        binding = FragmentWeightDeleteScreenBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mWeightListViewModel = new WeightListViewModel(requireActivity().getApplication());
        mWeightColors = getResources().getIntArray(R.array.subjectColors);
        //Set click listener for add weight button
        binding.openWeightEntryFragmentButton.setOnClickListener(v ->

                NavHostFragment.findNavController(this)
                        .navigate(R.id.action_WeightDeleteScreen_to_WeightEntryFragment)
        );

        // Create 2 grid layout columns
        mRecyclerView = binding.weightRecyclerView;
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(requireActivity(), 2);
        mRecyclerView.setLayoutManager(gridLayoutManager);
        // Obtain a reference to the MainActivity
        if (requireContext() instanceof MainActivity) {
            mainActivity = (MainActivity) getActivity();
            // Call get username method of MainActivity to set username
            assert mainActivity != null;
            username = mainActivity.getUsername();
        }
        // Show the weights
        mWeightListViewModel = new ViewModelProvider(this).get(WeightListViewModel.class);
        // Call updateUI() when the weight list changes
        mWeightListViewModel.getWeights(username).observe(requireActivity(), this::updateUI);
    }

    private WeightSortOrder getSettingsSortOrder() {
        //todo: set sort order settings
        // Set sort order from settings
        String sortOrderPref = "alpha";
        switch (sortOrderPref) {
            case "alpha": return WeightSortOrder.ALPHABETIC;
            case "new_first": return WeightSortOrder.NEW_FIRST;
            default: return WeightSortOrder.OLD_FIRST;
        }
    }


    private void updateUI(List<Weight> weightList) {
        mWeightAdapter = new WeightAdapter(weightList);
        mWeightAdapter.setSortOrder(getSettingsSortOrder());
        mRecyclerView.setAdapter(mWeightAdapter);
    }

    private void addWeightClick() {
        NavHostFragment.findNavController(this)
                .navigate(R.id.action_MainFragment_to_WeightEntryFragment);
    }

    //todo deleted oncreateOptionsMenu

    private class WeightHolder extends RecyclerView.ViewHolder
            implements View.OnClickListener, View.OnLongClickListener {
        private Weight mWeight;
        private final TextView mWeightDateTextView;
        private final TextView mWeightTextView;
        public WeightHolder(LayoutInflater inflater, ViewGroup parent) {
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
            itemView.setOnClickListener(this);
            mWeightDateTextView = itemView.findViewById(R.id.weight_date_text_view);
            mWeightTextView = itemView.findViewById(R.id.weigh_text_view);
            itemView.setOnLongClickListener(this);
        }

        public void bind(Weight weight, int position) {
            mWeight = weight;
            mWeightDateTextView.setText(String.format(getString(R.string.date_s), weight.getDate()));
            mWeightTextView.setText(String.format(getString(R.string.weight_d), weight.getWeight()));
            if (mSelectedWeightPosition == position) {
                // Make selected weight stand out
                mWeightDateTextView.setBackgroundColor(Color.RED);
            }
            else {
                // Make the background color dependent on the length of the weight string
                int colorIndex = weight.getDate().length() % mWeightColors.length;
                mWeightDateTextView.setBackgroundColor(ContextCompat.getColor(requireContext(),R.color.md_theme_dark_primaryContainer));
            }
        }

        @Override
        public void onClick(View view) {
            // todo: delete weight on click
        }

        @Override
        public boolean onLongClick(View view) {
            if (mActionMode != null) {
                return false;
            }
            mSelectedWeight = mWeight;
            mSelectedWeightPosition = getAbsoluteAdapterPosition();

            // Re-bind the selected item
            mWeightAdapter.notifyItemChanged(mSelectedWeightPosition);

            // Show the CAB

            mActionMode = mainActivity.startActionMode(mActionModeCallback);

            return true;
        }

        private final ActionMode.Callback mActionModeCallback = new ActionMode.Callback() {

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                // todo : Provide context menu for CAB


                MenuInflater inflater = mode.getMenuInflater();
                inflater.inflate(R.menu.menu_weight_delete, menu);
                mainActivity.setMenuDeleteWeightActionMode(true);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
                // Process action item selection
                // todo: fix action item clicked, for deleting weight
                if (item.getItemId() == R.id.delete_action) {
                    // Stop updateUI() from being called
                    mLoadWeightList = false;

                    // Delete from ViewModel
                    mWeightListViewModel.deleteWeight(mSelectedWeight);

                    // Remove from RecyclerView
                    mWeightAdapter.removeWeight(mSelectedWeight);

                    // Close the CAB
                    mode.finish();
                    return true;
                }

                return false;
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                mActionMode = null;

                // CAB closing, need to deselect item if not deleted
                mWeightAdapter.notifyItemChanged(mSelectedWeightPosition);
                mSelectedWeightPosition = RecyclerView.NO_POSITION;
                mainActivity.setMenuDeleteWeightActionMode(false);
            }
        };
    }
    private class WeightAdapter extends RecyclerView.Adapter<WeightHolder> {
        private final List<Weight> mWeightList;

        public WeightAdapter(List<Weight> weights) {
            mWeightList = weights;
        }

        @NonNull
        @Override
        public WeightHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater layoutInflater = LayoutInflater.from(requireContext());
            return new WeightHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(WeightHolder holder, int position){
            holder.bind(mWeightList.get(position), position);
        }

        @Override
        public int getItemCount() {
            return mWeightList.size();
        }

        public void addWeight(Weight weight) {

            // Add the new weight at the beginning of the list
            mWeightList.add(0, weight);

            // Notify the adapter that item was added to the beginning of the list
            notifyItemInserted(0);

            // Scroll to the top
            mRecyclerView.scrollToPosition(0);
        }

        public void removeWeight(Weight weight) {

            // Find weight in the list
            int index = mWeightList.indexOf(weight);
            if (index >= 0) {

                // Remove the weight
                mWeightList.remove(index);


                // Notify adapter of weight removal
                notifyItemRemoved(index);
            }
        }

        public void setSortOrder(WeightSortOrder sortOrder) {
            switch (sortOrder) {
                case ALPHABETIC:
                    mWeightList.sort(Comparator.comparing(Weight::getDate));
                    break;
                case NEW_FIRST:
                    // todo: set new first sort setting ".getUpdateTime"
                    mWeightList.sort(Comparator.comparing(Weight::getWeight));
                    break;
                default:
                    mWeightList.sort(Comparator.comparing(Weight::getDate));
            }
        }
    }
}