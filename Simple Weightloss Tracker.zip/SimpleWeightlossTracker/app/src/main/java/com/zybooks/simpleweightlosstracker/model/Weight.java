package com.zybooks.simpleweightlosstracker.model;

import static androidx.room.ForeignKey.CASCADE;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.Index;
import androidx.room.PrimaryKey;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Entity(foreignKeys = @ForeignKey(entity = Profile.class, parentColumns = "username",
        childColumns = "profile_username", onDelete = CASCADE),
        tableName = "weight",
        indices = {@Index(value = {"profile_username"})})
public class Weight {
    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private long mId;
    @ColumnInfo(name = "date")
    private String mDate;
    @ColumnInfo(name = "weight")
    private float mWeight;
    @ColumnInfo(name = "profile_username")
    private String mProfileUsername;

    public Weight(){}

    public Weight(String date, float weight, String username){
        mDate = date;
        mWeight = weight;
        mProfileUsername = username;

    }

    public void setId(long id) {
        mId = id;
    }

    public long getId() {
        return mId;
    }

    public String getDate() {
        return mDate;
    }
    public Date getParsedDate() {
        SimpleDateFormat sdf = new SimpleDateFormat("DDmmyy");
        try {
            return sdf.parse(mDate);
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

    }

    public void setDate(String text) {
        mDate = text;
    }

    public float getWeight() {
        return mWeight;
    }

    public void setWeight(float weight) { mWeight=weight;}

    public String getProfileUsername() {
        return mProfileUsername;
    }

    public void setProfileUsername(String profileId) {
        mProfileUsername = profileId;
    }
}