package com.zybooks.simpleweightlosstracker.repo;

import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.Transformations;
import androidx.room.Room;
import androidx.room.RoomDatabase;
import androidx.sqlite.db.SupportSQLiteDatabase;

import com.zybooks.simpleweightlosstracker.model.Weight;
import com.zybooks.simpleweightlosstracker.model.Profile;

import java.util.List;
import java.util.Objects;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicIntegerArray;

public class WeightLogRepository {
    private static final int NUMBER_OF_THREADS = 4;
    private static final ExecutorService mDatabaseExecutor = Executors.newFixedThreadPool(NUMBER_OF_THREADS);
    private static WeightLogRepository mWeightRepo;
    private final ProfileDao mProfileDao;
    private final WeightDao mWeightDao;
    private LiveData<Profile> currentProfile = new MutableLiveData<>();
    private String currentUsername = null;


    public static WeightLogRepository getInstance(Context context) {
        if (mWeightRepo == null) {
            mWeightRepo = new WeightLogRepository(context);
        }
        return mWeightRepo;
    }

    private WeightLogRepository(Context context) {
        RoomDatabase.Callback databaseCallback = new RoomDatabase.Callback() {
            @Override
            public void onCreate(@NonNull SupportSQLiteDatabase db) {
                super.onCreate(db);
            }
        };

        WeightLogDatabase database = Room.databaseBuilder(context, WeightLogDatabase.class, "study.db")
                .addCallback(databaseCallback)
                .build();

        mProfileDao = database.profileDao();
        mWeightDao = database.weightDao();

        if (mProfileDao.getProfiles().isInitialized()) {
            //todo: remove debug profile
            this.addProfile(new Profile("debug","debug"));
        }

    }
    public int getLatestWeight(String username){
        return mWeightDao.getLatestWeight(username);
    }
    public int getOldestWeight(String username){
        return mWeightDao.getOldestWeight(username);
    }
    public LiveData<Profile> checkCredentials(String username, String password) {
        return Transformations.switchMap(getProfile(username), profile -> {
            MutableLiveData<Profile> resultLiveData = new MutableLiveData<>();
            if (profile != null && profile.getPassword().equals(password)) {
                resultLiveData.setValue(profile);
            } else {
                resultLiveData.setValue(null);
            }
            return resultLiveData;
        });
    }


    public LiveData<Profile> getProfile(String username) {
        currentProfile = mProfileDao.getProfile(username);
        Observer<Profile> profileObserver = new Observer<Profile>() {
            @Override
            public void onChanged(Profile profile) {
                currentUsername = profile.getUsername();
                currentProfile.removeObserver(this);
            }
        };
        currentProfile.observeForever(profileObserver);
        return mProfileDao.getProfile(username);
    }

    public List<Profile> getProfiles() {
        return mProfileDao.getProfiles().getValue();
    }

    public LiveData<Boolean> doesProfileExist(String username) {
        return Transformations.map(mProfileDao.getProfile(username), Objects::nonNull);
    }
    public void addProfile(Profile profile) {
        mDatabaseExecutor.execute(() -> {
            long profileId = mProfileDao.addProfile(profile);
            profile.setId(profileId);
        });
        currentProfile = getProfile(profile.getUsername());
    }

    public void deleteProfile(Profile profile) {
        mDatabaseExecutor.execute(() -> mProfileDao.deleteProfile(profile));
    }

    public LiveData<Weight> getWeight(long weightId) {
        return mWeightDao.getWeight(weightId);
    }

    public LiveData<List<Weight>> getWeights(String profile_username) {
        return mWeightDao.getWeights(profile_username);
    }
    public void updateCurrentProfile() {
        if (currentUsername != null) {
            currentProfile = mWeightRepo.getProfile(currentUsername);
        }
    }
    public void addWeight(Weight weight) {
        mDatabaseExecutor.execute(() -> {
            long weightId = mWeightDao.addWeight(weight);
            weight.setId(weightId);
        });
        currentProfile = getProfile(currentUsername);
    }


    public void updateWeight(Weight weight) {
        mDatabaseExecutor.execute(() -> mWeightDao.updateWeight(weight));
    }
    public int getGoalWeight(String username) {
        AtomicIntegerArray goal = new AtomicIntegerArray(new int[0]);
        goal = new AtomicIntegerArray(new int[1]);
        AtomicIntegerArray finalGoal = goal;
        updateCurrentProfile();
        Observer<Profile> profileObserver = new Observer<Profile>() {
            @Override
            public void onChanged(Profile profile) {
                finalGoal.set(0, profile.getGoalWeight());
                currentProfile.removeObserver(this);
            }
        };
        currentProfile.observeForever(profileObserver);
        return finalGoal.get(0);

    }
    public void updateGoalWeight(int goalWeight){
        currentProfile = mWeightRepo.getProfile(currentUsername);
        Observer<Profile> profileObserver = new Observer<Profile>() {
            @Override
            public void onChanged(Profile profile) {
                profile.setGoalWeight(goalWeight);
                addProfile(profile);
                Log.d("WeightLogRepository", "Weight Goal Set");
                currentProfile.removeObserver(this);
            }
        };
        currentProfile.observeForever(profileObserver);
    }

    public void deleteWeight(Weight weight) {
        mDatabaseExecutor.execute(() -> mWeightDao.deleteWeight(weight));
    }

}