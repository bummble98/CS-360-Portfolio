package com.zybooks.simpleweightlosstracker.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.zybooks.simpleweightlosstracker.model.Profile;
import com.zybooks.simpleweightlosstracker.repo.WeightLogRepository;

public class LoginActivityViewModel extends AndroidViewModel {
    private final WeightLogRepository mWeightRepo;
    public LoginActivityViewModel(Application application) {
        super(application);
        mWeightRepo = WeightLogRepository.getInstance(application.getApplicationContext());
    }

    public void deleteProfile(Profile userProfile) {
        mWeightRepo.deleteProfile(userProfile);
    }

    public LiveData<Boolean> doesProfileExist(String username) {
        return mWeightRepo.doesProfileExist(username);
    }

    public LiveData<Profile> checkCredentials(String username, String password) {
        return mWeightRepo.checkCredentials(username,password);
    }

    public void addProfile(Profile profile) {
        mWeightRepo.addProfile(profile);
    }
}
