package com.zybooks.simpleweightlosstracker.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.zybooks.simpleweightlosstracker.model.Profile;
import com.zybooks.simpleweightlosstracker.repo.WeightLogRepository;

public class MainActivityViewModel extends AndroidViewModel {
    private final WeightLogRepository mWeightRepo;
    public MainActivityViewModel(Application application) {
        super(application);
        mWeightRepo = WeightLogRepository.getInstance(application.getApplicationContext());
    }
    public LiveData<Profile> getProfile(String username) {
        return mWeightRepo.getProfile(username);
    }
    public void deleteProfile(Profile userProfile) {
        mWeightRepo.deleteProfile(userProfile);
    }
    public void addProfile(Profile profile) {
        mWeightRepo.addProfile(profile);
    }
    public void updateGoalWeight(int goalWeight){
        mWeightRepo.updateGoalWeight(goalWeight);
    }
    public int getGoalWeight(String username){
        return mWeightRepo.getGoalWeight(username);
    }
}
