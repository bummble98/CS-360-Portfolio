package com.zybooks.simpleweightlosstracker.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.zybooks.simpleweightlosstracker.model.Profile;
import com.zybooks.simpleweightlosstracker.model.Weight;
import com.zybooks.simpleweightlosstracker.repo.WeightLogRepository;

import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;

public class MainFragmentViewModel extends AndroidViewModel {
    private static WeightLogRepository mWeightRepo;
    public MainFragmentViewModel(Application application) {
        super(application);
        mWeightRepo = WeightLogRepository.getInstance(application.getApplicationContext());
    }

    public static LiveData<List<Weight>> getWeights(String username) {
        return mWeightRepo.getWeights(username);
    }

    public LiveData<Profile> getProfile(String username) {
        return mWeightRepo.getProfile(username);
    }
    public void deleteProfile(Profile userProfile) {
        mWeightRepo.deleteProfile(userProfile);
    }
    public int getLatestWeight(String username){
        AtomicInteger atomicInteger = new AtomicInteger();
        Thread backgroundThread = new Thread(()->{
            atomicInteger.set(mWeightRepo.getLatestWeight(username));
        });
        backgroundThread.start();
        return atomicInteger.get();
    }
    public int getOldestWeight(String username){
        AtomicInteger atomicInteger = new AtomicInteger();
        Thread backgroundThread = new Thread(()->{
            atomicInteger.set(mWeightRepo.getOldestWeight(username));
        });
        backgroundThread.start();
        return atomicInteger.get();
    }
}
