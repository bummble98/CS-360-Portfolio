package com.zybooks.simpleweightlosstracker.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;

import com.zybooks.simpleweightlosstracker.model.Weight;
import com.zybooks.simpleweightlosstracker.repo.WeightLogRepository;

public class WeightEntryFragmentViewModel extends AndroidViewModel {
    private final WeightLogRepository mWeightRepo;
    public WeightEntryFragmentViewModel(Application application) {
        super(application);
        mWeightRepo = WeightLogRepository.getInstance(application.getApplicationContext());
    }

    public void addWeight(Weight weight) {
        mWeightRepo.addWeight(weight);
    }
}
