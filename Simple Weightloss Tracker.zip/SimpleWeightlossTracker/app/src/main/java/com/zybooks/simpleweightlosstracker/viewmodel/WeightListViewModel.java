package com.zybooks.simpleweightlosstracker.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.zybooks.simpleweightlosstracker.model.Weight;
import com.zybooks.simpleweightlosstracker.repo.WeightLogRepository;

import java.util.List;

public class WeightListViewModel extends AndroidViewModel {
    private final WeightLogRepository mWeightRepo;


    public WeightListViewModel(Application application) {
        super(application);
        mWeightRepo = WeightLogRepository.getInstance(application.getApplicationContext());
    }

    public LiveData<List<Weight>> getWeights(String username) {
        return (LiveData<List<Weight>>) mWeightRepo.getWeights(username);
    }

    public void addWeight(Weight weight) {
        mWeightRepo.addWeight(weight);
    }

    public void deleteWeight(Weight weight) {
        mWeightRepo.deleteWeight(weight);
    }
}
